--- GET_IS_HELI_ENGINE_RUNNING
-- @param heli The helicopter to check
-- @return Returns `true` if the helicopter's engine is running, `false` if it is not.
function Global.GetIsHeliEngineRunning(heli)
	return _in(0x3efe38d1, heli, _r)
end
