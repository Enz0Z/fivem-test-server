--- GET_HELI_REAR_ROTOR_DAMAGE_SCALE
-- @param heli The helicopter to check
-- @return Returns a value representing the damage scaling factor applied to the helicopter's rear rotor. The value ranges from `0.0` (no damage scaling) to`  1.0 ` (full damage scaling).
function Global.GetHeliRearRotorDamageScale(heli)
	return _in(0xc40161e2, heli, _rf)
end
