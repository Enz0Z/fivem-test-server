--- This is a getter for [SET_DISABLE_HELI_EXPLODE_FROM_BODY_DAMAGE](#\_0xEDBC8405B3895CC9)
-- @param heli The helicopter to check
-- @return Returns `true` if the helicopter is set to be protected from exploding due to minor body damage, `false` otherwise.
function Global.GetHeliDisableExplodeFromBodyDamage(heli)
	return _in(0x82afc0a3, heli, _r)
end
