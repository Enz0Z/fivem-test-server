--- GET_VEHICLE_HEADLIGHTS_COLOUR
function Global.GetVehicleHeadlightsColour(vehicle)
	return _in(0xd7147656, vehicle, _ri)
end
