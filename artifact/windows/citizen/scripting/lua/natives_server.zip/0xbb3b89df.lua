--- Returns all commands that are registered in the command system.
-- The data returned adheres to the following layout:
-- ```
-- [
-- {
-- "name": "cmdlist",
-- "resource": "resource",
-- "arity" = -1,
-- },
-- {
-- "name": "command1"
-- "resource": "resource_2",
-- "arity" = -1,
-- }
-- ]
-- ```
-- @return An object containing registered commands.
function Global.GetRegisteredCommands()
	return _in(0xd4bef069, _ro)
end
