--- Gets the current relationship group hash of a ped.
-- @param ped The target ped
-- @return The relationship group hash.
function Global.GetPedRelationshipGroupHash(ped)
	return _in(0x354f283c, ped, _ri)
end
