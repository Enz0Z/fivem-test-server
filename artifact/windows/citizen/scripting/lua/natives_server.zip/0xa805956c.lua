function Global.GetNumPlayerIndices()
	return _in(0x63d13184, _ri)
end
