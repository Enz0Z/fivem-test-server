--- REMOVE_CONVAR_CHANGE_LISTENER
-- @param cookie The cookie returned from [ADD_CONVAR_CHANGE_LISTENER](#\_0xAB7F7241)
function Global.RemoveConvarChangeListener(cookie)
	return _in(0xeac49841, cookie)
end
