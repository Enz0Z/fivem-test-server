--- GET_ENTITY_HEADING
function Global.GetEntityHeading(entity)
	return _in(0x972cc383, entity, _rf)
end
