function Global.SetHttpHandler(handler)
	return _in(0xf5c6330c, _mfr(handler))
end
