--- CREATE_PED_INSIDE_VEHICLE
-- @param pedType See [`CREATE_PED`](#\_0xD49F9B0955C367DE)
function Global.CreatePedInsideVehicle(vehicle, pedType, modelHash, seat, isNetwork, bScriptHostPed)
	return _in(0x3000f092, vehicle, pedType, _ch(modelHash), seat, isNetwork, bScriptHostPed, _ri)
end
