--- Gets the focus position (i.e. the position of the active camera in the game world) of a player.
-- @param playerSrc The player to get the focus position of
-- @return Returns a `Vector3` containing the focus position of the player.
function Global.GetPlayerFocusPos(playerSrc)
	return _in(0x586f80ff, _ts(playerSrc), _rv)
end
