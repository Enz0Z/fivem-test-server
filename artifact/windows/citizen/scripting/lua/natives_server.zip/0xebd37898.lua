--- Gets the current time online for a specified player.
-- @param playerSrc A player.
-- @return The current time online in seconds.
function Global.GetPlayerTimeOnline(playerSrc)
	return _in(0x67d2e605, _ts(playerSrc), _ri)
end
