function Global.GetEntityVelocity(entity)
	return _in(0xc14c9b6b, entity, _rv)
end
