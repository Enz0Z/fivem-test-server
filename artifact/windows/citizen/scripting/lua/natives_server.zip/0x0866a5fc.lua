function Global.GetPlayerMaxArmour(playerSrc)
	return _in(0x2a50657, _ts(playerSrc), _ri)
end
