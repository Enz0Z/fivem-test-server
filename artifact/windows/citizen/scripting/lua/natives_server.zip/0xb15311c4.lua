--- NETWORK_GET_VOICE_PROXIMITY_OVERRIDE
-- @param playerSrc The player handle
function Global.NetworkGetVoiceProximityOverride(playerSrc)
	return _in(0x7a6462f4, _ts(playerSrc), _rv)
end
