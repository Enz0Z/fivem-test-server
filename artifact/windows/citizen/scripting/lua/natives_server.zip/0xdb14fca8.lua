--- IS_FLASH_LIGHT_ON
-- @param ped The target ped.
-- @return Whether or not the ped's flash light is on.
function Global.IsFlashLightOn(ped)
	return _in(0x76876154, ped, _r)
end
