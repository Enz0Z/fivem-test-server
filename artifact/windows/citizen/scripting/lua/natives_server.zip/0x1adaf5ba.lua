--- IS_PLAYER_IN_FREE_CAM_MODE
-- @param playerSrc The player to get the free camera mode status of
-- @return Returns if the player is in free camera mode.
function Global.IsPlayerInFreeCamMode(playerSrc)
	return _in(0x1f14f2ac, _ts(playerSrc), _r)
end
