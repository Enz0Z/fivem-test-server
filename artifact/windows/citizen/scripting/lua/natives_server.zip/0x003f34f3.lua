--- GET_PLAYER_PED
function Global.GetPlayerPed(playerSrc)
	return _in(0x6e31e993, _ts(playerSrc), _ri)
end
