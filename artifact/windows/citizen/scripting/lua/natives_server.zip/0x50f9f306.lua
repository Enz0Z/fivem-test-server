--- It allows to flag an entity to ignore the request control filter policy.
-- @param entity The entity handle to ignore the request control filter.
-- @param ignore Define if the entity ignores the request control filter policy.
function Global.SetEntityIgnoreRequestControlFilter(entity, ignore)
	return _in(0x9f7f8d36, entity, ignore)
end
