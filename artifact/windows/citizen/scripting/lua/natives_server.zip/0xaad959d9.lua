function Global.EnableEnhancedHostSupport(enabled)
	return _in(0xf97b1c93, enabled)
end
