--- IS_HELI_TAIL_BOOM_BROKEN
-- @param heli The helicopter to check
-- @return Returns `true` if the helicopter's tail boom is broken, `false` if it is intact.
function Global.IsHeliTailBoomBroken(heli)
	return _in(0x2c59f987, heli, _r)
end
