--- Used for freemode (online) characters.
-- **This is the server-side RPC native equivalent of the client native [\_SET_PED_HAIR_COLOR](?\_0x4CFFC65454C93A49).**
function Global.SetPedHairColor(ped, colorID, highlightColorID)
	return _in(0xbb43f090, ped, colorID, highlightColorID)
end
