--- GET_ENTITY_ORPHAN_MODE
-- @param entity The entity to get the orphan mode of
-- @return Returns the entities current orphan mode, refer to enum in [SET_ENTITY_ORPHAN_MODE](#\_0x489E9162)
function Global.GetEntityOrphanMode(entity)
	return _in(0xd16ea02f, entity, _ri)
end
