--- Returns the hash of weapon the Ped is currently using.
-- @param ped The target ped.
-- @return The weapon hash.
function Global.GetCurrentPedWeapon(ped)
	return _in(0xb0237302, ped, _ri)
end
