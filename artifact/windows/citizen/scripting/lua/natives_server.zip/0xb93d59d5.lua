--- Requests the commerce data from Tebex for the specified player, including the owned SKUs.
-- Use [`IS_PLAYER_COMMERCE_INFO_LOADED_EXT`](#\_0x1D14F4FE) to check if it has loaded.
-- This will not automatically update whenever a client purchases a package, if you want to fetch new purchases you will need to call this native again.
-- This native will temporarily cache the players commerce data for 10 seconds, a call to this native after 10 seconds will re-fetch the players commerce data.
-- @param playerSrc The player handle
function Global.LoadPlayerCommerceDataExt(playerSrc)
	return _in(0x7995539e, _ts(playerSrc))
end
