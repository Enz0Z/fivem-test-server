--- HAS_ENTITY_BEEN_MARKED_AS_NO_LONGER_NEEDED
function Global.HasEntityBeenMarkedAsNoLongerNeeded(vehicle)
	return _in(0x9c9a3be0, vehicle, _r)
end
